在Windows右键菜单中增加“Open With CMD”选项，随时随地用CMD打开目录。

## 安装 Install
1. 下载压缩包；
1. 将压缩包解压到运行目录；
1. 执行Install.exe;

## 使用 Usage
1. 选择要进入的目录；
1. 点右键，在右键菜单中选择“Open With CMD”；

## 卸载 Uninstall
1. 运行Uninstall；
1. 删除安装目录；
